
import java.net.*;
import org.json.*;
import org.apache.commons.io.*;
import java.io.*;



public class main{
    public static void main(String[] args) throws URISyntaxException, IOException{
        System.out.println("Test");
        //TODO get ip address
        String ipAddress = getIP();
        System.out.println(ipAddress);
        //todo get long lat
        String longLat = getLongLat(ipAddress);
    //    System.out.println(longLat);
        //TODO get weather

        //TODO print appropriate weather symbols
        //TODO provide hi, lo, air qual, uvvindex, and fun fact
}
    static String getIP() throws URISyntaxException, IOException{
        URI uri = new URI("http://checkip.amazonaws.com");
        URL url = uri.toURL();
        URLConnection con = url.openConnection();
        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);
        return(body);


}

static String getLongLat(String ipAddress) throws URISyntaxException, IOException{
    URI uri = new URI("http://www.geoplugin.net/csv.gp?ip=" + ipAddress.substring(0, ipAddress.length()-1));
    URL url = uri.toURL();
    URLConnection con = url.openConnection();
    InputStream in = con.getInputStream();
    String encoding = con.getContentEncoding();
    encoding = encoding == null ? "UTF-8" : encoding;
    try {
        LineIterator it = IOUtils.lineIterator(in, encoding);
        while (it.hasNext()) {
          String line = it.next();
      //    System.out.println(line);
          String[] lineSplitFirst = line.split("[\\r\\n]+");
          int i = 0;
          System.out.println(line);
          for (String x : lineSplitFirst){
          //  System.out.println("ggg");
          }
        //  System.out.println(lineSplitFirst[0]);
       //   System.out.println(lineSplitFirst[16]);
      //    System.out.println(lineSplitFirst[17]);
        }}
    finally{
    }
    return "";

}
}