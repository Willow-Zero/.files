import sys

test = sys.argv[1]
bytes = sys.argv[2]
print(test,bytes)




def xor_hex_with_key(hex_string, hex_key):
    # Convert the hex string to bytes
    string_bytes = bytes.fromhex(hex_string)
    
    # Convert the hex key to bytes
    key_bytes = bytes.fromhex(hex_key)
    
    # XOR each byte of the string with the key, cycling through the key
    xored_bytes = bytes([b ^ key_bytes[i % len(key_bytes)] for i, b in enumerate(string_bytes)])
    
    # Convert the resulting bytes back to a text string
    # We assume the resulting text is ASCII; adjust encoding if needed
    try:
        xored_text = xored_bytes.decode('ascii')
    except UnicodeDecodeError:
        xored_text = xored_bytes.decode('utf-8', errors='replace')
    
    return xored_text




# Example usage
hex_string = "48656c6c6f2c20576f726c6421"  # This is "Hello, World!" in hex
hex_key = "1f2a3c"
xored_result = xor_hex_with_key(hex_string, hex_key)
print(f"Original Hex: {hex_string}")

