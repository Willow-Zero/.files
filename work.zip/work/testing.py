arr1 = [13,27,45]
arr2 = [21,27,48]
prefixLength = 0
for x in arr1:
    stringx = str(x)
    for y in arr2:
        stringy = str(y)
        continiue = True
        thisPrefix = 0
        while continiue:
            if stringy == stringx:
                thisPrefix = len(stringy)
            if stringy[:thisPrefix+1] == stringx[:thisPrefix+1] and stringy!=stringx:
                thisPrefix += 1
                print("thisPrefix = " + str(thisPrefix))
            if stringy==stringx or stringy[:thisPrefix+1] != stringx[:thisPrefix+1]:
                continiue = False
                if thisPrefix>prefixLength:
                    prefixLength = thisPrefix
                    print(prefixLength)
print(prefixLength)
